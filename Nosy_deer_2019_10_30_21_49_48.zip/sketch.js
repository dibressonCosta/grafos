let graph = new Graph();
var cities = {};
var totalCities = 9;
var adja = [0];
var recordDistance;
var bestEver;

function setup() {
  canvas = createCanvas(window.innerWidth, window.innerHeight);
  for (var i = 0; i < totalCities; i++) {
    var v = createVector(random(width, 2), random(height, 2));
    cities[i] = v;
    graph.addNode(i);
  }
  calcEdge(cities);

}

function draw() {

  var keys = Object.keys(cities);
  //var bla = randomizeKeys(keys);
  //var d = calcDistance(bla);
  //if (d < recordDistance) {
  // bestEver = bla;
  //recordDistance = d;
  //}

  background(0);

  stroke(255);
  strokeWeight(1);
  noFill();
  beginShape();
  for (var key1 in cities) {
    for (var key2 in cities) {
      vertex(cities[key1].x, cities[key1].y);
      //vertex(cities[key2].x, cities[key2].y);
    }
  }
  endShape();

  stroke(255, 0, 255);
  strokeWeight(4);
  noFill();
  beginShape();
  for (var key in bestEver) {
    vertex(bestEver[key].x, bestEver[key].y);
  }
  endShape();

  fill(255, 0, 255);
  for (var key in cities) {
    ellipse(cities[key].x, cities[key].y, 10, 10);
  }
}



function calcEdge(points) {
  console.log(graph.nodes[4]);
  for (i = 0; i < totalCities; i++) {
    var adj = i;
    while (adj == i && adja.includes(adj)) {
      adj = Math.floor(Math.random() * totalCities);
    }

    console.log("1 aleatorio" + adj);
    if (!adja.includes(adj) && i == 0) {
      adja.push(adj);
      if(adj+1 < totalCities){
        adja.push(adj+1);
      }else{
        adja.push(adj - 1);
      }
      
    } else {
      if (!adja.includes(adj)) {
        adja.push(adj);
      }
    }
  }
  console.log(adja);
  return 0;
}